Stretchy Navigation
=========

A rounded navigation trigger that stretches on click/tap to reveal the navigation items.

[Article on CodyHouse](http://codyhouse.co/gem/stretchy-navigation/)

[Demo](http://codyhouse.co/demo/stretchy-navigation/index.html)

Icons: [Nucleo](https://nucleoapp.com/)
 
[Terms](http://codyhouse.co/terms/)
